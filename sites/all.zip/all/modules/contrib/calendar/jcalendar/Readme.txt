Just some credits.

The throbber is from thickbox and the x is from a jquery tooltip library, although I cannot remember which.
